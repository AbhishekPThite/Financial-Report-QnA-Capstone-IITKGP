# Financial Research Copilot — Starter Dataset

## What's included
- `gold_questions_starter.csv`: 60-question evaluation starter set. Five questions have verified seed answers; the remaining questions are deliberately marked `needs_annotation` so you can populate gold answers from the source filing rather than train/evaluate against invented labels.
- `document_manifest.csv`: official SEC filing URLs for Microsoft FY2023–FY2025 10-K reports.
- `verified_seed_metrics.csv`: selected reported values from Microsoft's FY2025 10-K summary results table.
- `calculation_rules.csv`: core financial formulas and validation notes.

## Starter source
Microsoft FY2025 Form 10-K:
https://www.sec.gov/Archives/edgar/data/789019/000095017025100235/msft-20250630.htm

The filing reports (USD millions, except EPS):
- FY2025 revenue: 281,724; FY2024 revenue: 245,122
- FY2025 gross margin: 193,893; FY2024 gross margin: 171,008
- FY2025 operating income: 128,528; FY2024 operating income: 109,433
- FY2025 net income: 101,832; FY2024 net income: 88,136
- FY2025 diluted EPS: 13.64; FY2024 diluted EPS: 11.80

## Important evaluation guidance
1. Do not treat blank `gold_answer` fields as zero or as model targets. Annotate them using the filing and mark them `gold_verified` only after a human checks the value and evidence.
2. Store page/section/table and a short supporting quote or normalized table row in your annotation workflow.
3. For calculated answers, record the input values, formula, units, and rounding convention.
4. The 10-K links are source documents, not included copies. Download them from SEC EDGAR and follow SEC access policies.
5. Fiscal years are Microsoft's fiscal years, ending June 30. Do not confuse fiscal year with calendar year.
6. This starter set is designed for learning and benchmarking, not investment decisions.

## Suggested next step
Download the FY2025 10-K first, parse it, and use Q001–Q005 to validate document ingestion, retrieval, citations, and basic answer generation. Then annotate the remaining 55 questions before using the full set as a formal evaluation benchmark.
